
# Easter Bunny Tracker - Slatka Uskršnja Aplikacija

Aplikacija koja prati uskršnjeg zeca po svijetu! Prikazuje globus, posjećene gradove s Wikipedijom, broj poklona i svira uskršnja glazba. Dvojezična: hrvatski i engleski.

## Pokretanje

```bash
npm install
npm run dev
```

## Deploy (Vercel)

1. Uploadaj projekt na GitHub (npr. `easter-bunny-tracker` repo).
2. Idi na https://vercel.com i spoji repo.
3. Aplikacija će biti dostupna online automatski.

Sretan Uskrs!
